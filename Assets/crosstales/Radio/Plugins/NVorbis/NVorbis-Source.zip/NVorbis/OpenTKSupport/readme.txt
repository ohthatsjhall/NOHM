This code originated from https://github.com/renaudbedard/nvorbis/ and
was released to the public domain by the author (Renaud Bedard).  No
other license is intended or required.