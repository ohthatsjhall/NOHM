﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("NVorbis")]
[assembly: AssemblyDescription("A Vorbis decoder in C#")]
[assembly: AssemblyCompany("crosstales LLC")]
[assembly: AssemblyProduct("NVorbis")]
[assembly: AssemblyCopyright("Copyright © Andrew Ward 2014")]

[assembly: ComVisible(false)]

[assembly: AssemblyVersion("0.8.4.0")]
[assembly: AssemblyFileVersion("0.8.4.0")]
